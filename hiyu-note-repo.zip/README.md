# 比喩ノート

鬱・感情・「不快回避」を何かに例えるアイデア集です。歌詞や物語のモチーフに使います。
検索、テーマ別・雰囲気別の絞り込み、お気に入り、追加・編集・削除、XML/JSON書き出しができます。

## ファイル構成

```
index.html        ページ本体（これ1枚で動きます）
data/data.json    比喩・歌詞・おすすめモチーフのデータ
img/              比喩の画像
.nojekyll         GitHub Pages でそのまま配信するための空ファイル
```

## GitHub Pages で公開する

1. このフォルダの中身をリポジトリのルートに置いて push します。
2. リポジトリの Settings → Pages で、Source を「Deploy from a branch」、Branch を `main` / `(root)` にします。
3. 数分後に `https://<ユーザー名>.github.io/<リポジトリ名>/` で開けます。

ローカルで確認するときは、`index.html` を直接開くと `data.json` が読めないので、簡易サーバーを使ってください。

```
python3 -m http.server
```

## 編集のしかた（GitHub Pages 版）

- 「＋ 追加」や各カードの ✎ から編集すると、**そのブラウザの中に保存**されます。
- 変更をリポジトリに反映するときは、メニューの「JSONを書き出す」でダウンロードした `data.json` を `data/data.json` に上書きしてコミットします。
- 新しく追加した画像は `data.json` の中に埋め込まれます（480px に縮小した JPEG）。
- 「ブラウザ内の編集を破棄して data.json に戻す」で、リポジトリの状態に戻せます。

## claude.ai 版との違い

claude.ai 上で開いた場合は、編集内容がクラウドに保存され、どの端末からでも同じデータが見えます。
GitHub に移すときは、claude.ai 版のメニューから「JSONを書き出す」を実行し、その `data.json` で `data/data.json` を置き換えてください。

## データ形式（data/data.json）

```json
{
  "metaphors": [
    { "id": "m001", "sec": "utsu", "theme": "鬱", "text": "水中の花",
      "desc": "説明", "style": "王道", "kw": "キーワード", "alt": "別案1、別案2",
      "img": "img/m01.jpg", "order": 1 }
  ],
  "lyrics": [ { "id": "l001", "title": "タイトル", "theme": "鬱", "body": "1行目\n2行目", "order": 1 } ],
  "picks":  [ { "id": "p001", "motif": "モチーフ", "desc": "説明", "order": 1 } ]
}
```

`sec` は項目の種類です（utsu / poetic / emotion / poison / plant / tricky / surreal / avoid / avoidShort / other）。

## 画像について

画像は、元の会話で検索結果として表示されたものを切り出しています。他の人の作品が含まれるため、リポジトリは非公開（Private）にしておくのがおすすめです。
GitHub Pages を非公開リポジトリで使うには有料プランが必要です。無料で公開する場合は、`img/` を外して `data.json` の `img` を空にしてください。
